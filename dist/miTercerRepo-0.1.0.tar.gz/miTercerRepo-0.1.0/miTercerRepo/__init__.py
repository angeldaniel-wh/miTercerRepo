def saluda(nombre):
    return f"Hola, {nombre}!"